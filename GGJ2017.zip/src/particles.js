var particles = [];

function emitParticle(image, frames, frameTime, x, y) {

}