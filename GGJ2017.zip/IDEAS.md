# Potential additions
* Maybe the enemies only move when you observe them

* Pivot
    - Resonate with friend (correct frequency of wave)
        - if you fuck up, the friends become enemies
        - jump on enemies heads to blow them up
        - different types of allies 
            - some detect enemies (and then die after shooting 20 waves out), other shoot them, others fly into them and blow them up
        - use echo gun to make them solid
        - survive instead of move through levels
        - some enemies, when they die, can be turned into friends
        - health and stuff spawns around the level
        - batteries for the gun spawn when enemies die and around the level
        - gun overheats if you hold spacebar for too long
        - color on the gun changes to reflect the frequency
        - shoot enemies with correct color
        - match frequency with almost dead enemies

    - Magnet gun puzzles